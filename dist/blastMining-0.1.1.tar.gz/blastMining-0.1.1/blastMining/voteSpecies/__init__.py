'''
blastMining: vote at species level for all
'''
name='voteSpecies'
from .voteSpecies import main, add_arguments