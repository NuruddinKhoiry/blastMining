'''
blastMining: besthit method
'''
name='beshit'
from .besthit import main, add_arguments