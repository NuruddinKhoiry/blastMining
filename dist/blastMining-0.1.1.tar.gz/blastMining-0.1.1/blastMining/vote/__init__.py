'''
blastMining: voting method with pident cut-off
'''
name='vote'
from .vote import main, add_arguments