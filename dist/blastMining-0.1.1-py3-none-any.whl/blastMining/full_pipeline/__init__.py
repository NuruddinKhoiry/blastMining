'''
blastMining: Running BLAST + mining the output 
'''
name='full_pipeline'
from .full_pipeline import main, add_arguments