'''
blastMining: lca method
'''
name='lca'
from .lca import main, add_arguments