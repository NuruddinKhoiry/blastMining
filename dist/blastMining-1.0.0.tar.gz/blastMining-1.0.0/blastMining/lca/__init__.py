'''
blastMining: lca method

blastMining v.1.0.0

Written by: Ahmad Nuruddin Khoiri (nuruddinkhoiri34@gmail.com)

'''
name='lca'
from .lca import main, add_arguments