'''
blastMining: Running BLAST + mining the output 

blastMining v.1.2.0

Written by: Ahmad Nuruddin Khoiri (nuruddinkhoiri34@gmail.com)

'''
name='full_pipeline'
from .full_pipeline import main, add_arguments