'''
blastMining: besthit method

blastMining v.1.2.0

Written by: Ahmad Nuruddin Khoiri (nuruddinkhoiri34@gmail.com)

'''
name='beshit'
from .besthit import main, add_arguments