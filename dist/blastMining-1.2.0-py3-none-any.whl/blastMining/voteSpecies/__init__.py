'''
blastMining: vote at species level for all

blastMining v.1.2.0

Written by: Ahmad Nuruddin Khoiri (nuruddinkhoiri34@gmail.com)

'''
name='voteSpecies'
from .voteSpecies import main, add_arguments